# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['txp_test']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0.1,<9.0.0', 'pytest>=6.2.4,<7.0.0']

entry_points = \
{'console_scripts': ['txp_test = txp_test.main:cli_entrypoint']}

setup_kwargs = {
    'name': 'test',
    'version': '0.1.0',
    'description': 'Testing some python functionalities with poetry',
    'long_description': None,
    'author': 'Marco',
    'author_email': 'kada9001@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
